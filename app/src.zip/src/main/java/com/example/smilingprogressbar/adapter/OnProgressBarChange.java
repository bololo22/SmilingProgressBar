package com.example.smilingprogressbar.adapter;

/**
 * Created by Android1 on 7/8/2015.
 */
public interface OnProgressBarChange {
    void onChange(int value);
}
